from fastapi import FastAPI, Depends
from src.services.task_service import TaskService
from src.repositories.task_repository import TaskRepository
from src.domains.task import Task
from src.utils.database import engine, Base

Base.metadata.create_all(bind=engine)
app = FastAPI()

repository = TaskRepository()
service = TaskService(repository)

@app.post("/tasks/")
def create_task(task: Task):
    return service.create_task(task)

@app.get("/tasks/")
def list_tasks():
    return service.get_all_tasks()

@app.get("/")
def read_root():
    return {"message": "Welcome to the Task API! Use /tasks/ to manage tasks."}
